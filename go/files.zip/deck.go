package main

import "math/rand"

// testAttackDeck returns a shuffled set of attack cards covering the main mechanics.
func testAttackDeck() []Card {
	cards := []Card{
		// normal attacks
		{ID: "espada-humana", Name: "Espada Humana", Tags: TagAttack, AttackDamage: 10, AttackElement: ElementNormal, Price: 3, Rarity: Common},
		{ID: "foice-do-trabalhador", Name: "Foice do Trabalhador", Tags: TagAttack, AttackDamage: 5, AttackElement: ElementNormal, Price: 2, Rarity: Common},
		{ID: "adaga-de-ferro", Name: "Adaga de Ferro", Tags: TagAttack, AttackDamage: 7, AttackElement: ElementNormal, Price: 2, Rarity: Common},
		{ID: "arco-humanoide", Name: "Arco Humanoide", Tags: TagAttack, AttackDamage: 9, AttackElement: ElementNormal, Price: 3, Rarity: Common},
		{ID: "lanca-de-guerra", Name: "Lança de Guerra", Tags: TagAttack, AttackDamage: 8, AttackElement: ElementNormal, Price: 4, Rarity: Uncommon},
		{ID: "estrela-de-aco", Name: "Estrela de Aço", Tags: TagAttack, AttackDamage: 30, AttackElement: ElementNormal, Price: 8, Rarity: Rare},
		// elemental attacks
		{ID: "bola-de-fogo", Name: "Bola de Fogo", Tags: TagAttack, AttackDamage: 3, AttackElement: ElementFire, Price: 2, Rarity: Common},
		{ID: "faca-luciferiana", Name: "Faca Luciferiana", Tags: TagAttack, AttackDamage: 3, AttackElement: ElementFire, Price: 2, Rarity: Common},
		{ID: "lanca-de-gelo", Name: "Lança de Gelo", Tags: TagAttack, AttackDamage: 1, AttackElement: ElementWater, Price: 1, Rarity: Common},
		{ID: "chicotada-gelida", Name: "Chicotada Gélida", Tags: TagAttack, AttackDamage: 3, AttackElement: ElementWater, Price: 2, Rarity: Common},
		{ID: "pedrado", Name: "Pedrado", Tags: TagAttack, AttackDamage: 8, AttackElement: ElementRock, Price: 3, Rarity: Common},
		{ID: "espada-de-trino", Name: "Espada de Trino", Tags: TagAttack, AttackDamage: 2, AttackElement: ElementWood, Price: 1, Rarity: Common},
		// light attacks (unblockable)
		{ID: "lanca-angelical", Name: "Lança Angelical", Tags: TagAttack, AttackDamage: 5, AttackElement: ElementLight, Price: 3, Rarity: Uncommon},
		{ID: "caimento-do-anjo", Name: "Caimento do Anjo", Tags: TagAttack, AttackDamage: 10, AttackElement: ElementLight, Price: 5, Rarity: Uncommon},
		// + cards (stackable modifiers)
		{ID: "pena-de-ouro", Name: "Pena de Ouro", Tags: TagAttack | TagPlus, IsPlus: true, AttackDamage: 7, AttackElement: ElementNormal, Price: 4, Rarity: Uncommon},
		{ID: "ferro-magico", Name: "Ferro Mágico Imbuído", Tags: TagAttack | TagPlus, IsPlus: true, AttackDamage: 5, AttackElement: ElementNormal, Price: 3, Rarity: Uncommon},
		{ID: "magma-derretido", Name: "Magma Derretido", Tags: TagAttack | TagPlus, IsPlus: true, AttackDamage: 3, AttackElement: ElementFire, Price: 2, Rarity: Common},
	}
	shuffled := make([]Card, len(cards))
	copy(shuffled, cards)
	rand.Shuffle(len(shuffled), func(i, j int) { shuffled[i], shuffled[j] = shuffled[j], shuffled[i] })
	return shuffled
}

// testSecondaryDeck returns a shuffled set of defense / consumable cards.
func testSecondaryDeck() []Card {
	cards := []Card{
		// normal defense
		{ID: "peitoral-humanoide", Name: "Peitoral Humanoide", Tags: TagDefense, DefenseValue: 10, DefenseElement: ElementNormal, Price: 4, Rarity: Common},
		{ID: "escudeiro-de-aco", Name: "Escudeiro de Aço", Tags: TagDefense, DefenseValue: 9, DefenseElement: ElementNormal, Price: 3, Rarity: Common},
		{ID: "mao-de-ferro", Name: "Mão de Ferro", Tags: TagDefense, DefenseValue: 6, DefenseElement: ElementNormal, Price: 2, Rarity: Common},
		{ID: "botadao-de-couro", Name: "Botadão de Couro", Tags: TagDefense, DefenseValue: 2, DefenseElement: ElementNormal, Price: 1, Rarity: Common},
		{ID: "bone-humanoide", Name: "Bone Humanoide", Tags: TagDefense, DefenseValue: 1, DefenseElement: ElementNormal, Price: 1, Rarity: Common},
		{ID: "escudo-da-divindade", Name: "Escudo da Divindade", Tags: TagDefense, DefenseValue: 30, DefenseElement: ElementNormal, Price: 8, Rarity: Rare},
		// elemental defense
		{ID: "pe-quente", Name: "Pé Quente", Tags: TagDefense, DefenseValue: 3, DefenseElement: ElementFire, Price: 2, Rarity: Common},
		{ID: "capa-infernal", Name: "Capa Infernal", Tags: TagDefense, DefenseValue: 6, DefenseElement: ElementWater, Price: 3, Rarity: Uncommon},
		{ID: "muralha-de-gelo", Name: "Muralha de Gelo", Tags: TagDefense, DefenseValue: 15, DefenseElement: ElementWater, Price: 5, Rarity: Rare},
		{ID: "tabua", Name: "Tábua", Tags: TagDefense, DefenseValue: 3, DefenseElement: ElementWood, Price: 2, Rarity: Common},
		{ID: "escudo-da-floresta", Name: "Escudo da Floresta", Tags: TagDefense, DefenseValue: 5, DefenseElement: ElementWood, Price: 3, Rarity: Common},
		// hybrid: attack + defense
		{ID: "mao-fria", Name: "Mão Fria", Tags: TagDefense | TagAttack,
			DefenseValue: 4, DefenseElement: ElementWater,
			AttackDamage: 4, AttackElement: ElementWater, Price: 3, Rarity: Uncommon},
		// reflect / swingback (card IS the behavior, not a stance)
		{ID: "espelho", Name: "Espelho", Tags: TagDefense, IsReflect: true, Price: 6, Rarity: Rare},
		{ID: "espada-de-vidral", Name: "Espada de Vidral", Tags: TagDefense | TagAttack,
			AttackDamage: 10, AttackElement: ElementRock, IsSwingBack: true, Price: 5, Rarity: Uncommon},
		// consumables (heal / cleanse)
		{ID: "sangue-divino", Name: "Sangue Divino", Tags: TagConsumable,
			Effects: []Effect{{Trigger: OnPlay, Scope: ScopeSelf, Payload: "heal", Value: 25}}, Price: 4, Rarity: Uncommon},
		{ID: "sangue-humanoide", Name: "Sangue Humanoide", Tags: TagConsumable,
			Effects: []Effect{{Trigger: OnPlay, Scope: ScopeSelf, Payload: "heal", Value: 5}}, Price: 2, Rarity: Common},
		{ID: "sabao-de-petolas", Name: "Sabão de Pétalas Florais", Tags: TagConsumable,
			Effects: []Effect{{Trigger: OnPlay, Scope: ScopeSelf, Payload: "cleanseNegative"}}, Price: 3, Rarity: Uncommon},
	}
	shuffled := make([]Card, len(cards))
	copy(shuffled, cards)
	rand.Shuffle(len(shuffled), func(i, j int) { shuffled[i], shuffled[j] = shuffled[j], shuffled[i] })
	return shuffled
}

func drawN(deck []Card, n int) (hand, remaining []Card) {
	if n > len(deck) {
		n = len(deck)
	}
	return deck[:n], deck[n:]
}
