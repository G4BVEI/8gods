package main

import (
	"log"
	"math/rand"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

var rng = rand.New(rand.NewSource(time.Now().UnixNano()))

func randomID(prefix string) string {
	const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
	b := make([]byte, 6)
	for i := range b {
		b[i] = chars[rng.Intn(len(chars))]
	}
	return prefix + "-" + string(b)
}

const maxPlayersPerRoom = 8

var (
	hubMu sync.Mutex
	rooms = map[string]*Room{}
)

func findOrCreateRoom() *Room {
	hubMu.Lock()
	defer hubMu.Unlock()
	for _, r := range rooms {
		if r.PlayerCount() < maxPlayersPerRoom && r.game == nil {
			return r
		}
	}
	id := randomID("room")
	r := NewRoom(id)
	rooms[id] = r
	go r.Run()
	return r
}

func cleanRoom(r *Room) {
	hubMu.Lock()
	defer hubMu.Unlock()
	if r.PlayerCount() == 0 {
		delete(rooms, r.ID)
		log.Printf("[%s] room removed\n", r.ID)
	}
}

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool { return true },
}

func handleWS(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println("upgrade:", err)
		return
	}

	playerID := randomID("player")
	room := findOrCreateRoom()

	c := &Connection{
		PlayerID: playerID,
		Conn:     conn,
		Send:     make(chan []byte, 64),
	}

	// register connection before starting write pump
	hubMu.Lock()
	room.conns[playerID] = c
	ids := make([]string, 0, len(room.conns))
	for id := range room.conns {
		ids = append(ids, id)
	}
	hubMu.Unlock()

	// notify this player
	c.Send <- marshal(EvtJoined, JoinedPayload{
		PlayerID: playerID,
		RoomID:   room.ID,
		Players:  ids,
	})
	// notify others
	room.broadcast(playerID, EvtPlayerJoined, PlayerJoinedPayload{PlayerID: playerID})

	go c.writePump()

	log.Printf("[%s] player %s joined\n", room.ID, playerID)

	// read loop — pushes messages into the room inbox
	for {
		_, data, err := conn.ReadMessage()
		if err != nil {
			break
		}
		room.Receive(playerID, data)
	}

	room.Leave(playerID)
	room.broadcastAll(EvtPlayerLeft, PlayerLeftPayload{PlayerID: playerID})
	log.Printf("[%s] player %s left\n", room.ID, playerID)
	cleanRoom(room)
}

func main() {
	http.HandleFunc("/ws", handleWS)
	http.Handle("/", http.FileServer(http.Dir(".")))
	log.Println("listening on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

var _ = time.Now // ensure time import is used
