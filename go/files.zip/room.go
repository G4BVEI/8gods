package main

import (
	"encoding/json"
	"log"

	"github.com/gorilla/websocket"
)

// Connection wraps a player's websocket with a buffered outbound channel.
type Connection struct {
	PlayerID string
	Conn     *websocket.Conn
	Send     chan []byte
}

// writePump drains the Send channel and writes to the websocket.
// Runs in its own goroutine per player.
func (c *Connection) writePump() {
	defer c.Conn.Close()
	for data := range c.Send {
		if err := c.Conn.WriteMessage(websocket.TextMessage, data); err != nil {
			return
		}
	}
}

// roomEvent is an internal event dispatched to the room goroutine.
type roomEventKind int

const (
	kindJoin    roomEventKind = iota
	kindLeave   roomEventKind = iota
	kindMessage roomEventKind = iota
)

type roomEvent struct {
	kind     roomEventKind
	playerID string
	conn     *Connection // set on kindJoin
	data     []byte      // set on kindMessage
}

// Room owns all connection and game state for a group of players.
// All mutable state is accessed exclusively by the room goroutine — no mutexes needed.
type Room struct {
	ID    string
	inbox chan roomEvent

	// owned by room goroutine
	conns map[string]*Connection
	ready map[string]bool
	game  *Game
}

func NewRoom(id string) *Room {
	return &Room{
		ID:    id,
		inbox: make(chan roomEvent, 64),
		conns: make(map[string]*Connection),
		ready: make(map[string]bool),
	}
}

// Join enqueues a join event from the WS handler goroutine.
func (r *Room) Join(c *Connection) {
	r.inbox <- roomEvent{kind: kindJoin, playerID: c.PlayerID, conn: c}
}

// Leave enqueues a leave event from the WS handler goroutine.
func (r *Room) Leave(playerID string) {
	r.inbox <- roomEvent{kind: kindLeave, playerID: playerID}
}

// Receive enqueues an inbound WS message from the WS handler goroutine.
func (r *Room) Receive(playerID string, data []byte) {
	r.inbox <- roomEvent{kind: kindMessage, playerID: playerID, data: data}
}

// Run is the room goroutine. It is the only writer to r.conns, r.ready, r.game.
func (r *Room) Run() {
	for ev := range r.inbox {
		switch ev.kind {
		case kindJoin:
			r.conns[ev.playerID] = ev.conn
		case kindLeave:
			if c, ok := r.conns[ev.playerID]; ok {
				close(c.Send)
				delete(r.conns, ev.playerID)
			}
			delete(r.ready, ev.playerID)
		case kindMessage:
			r.dispatch(ev.playerID, ev.data)
		}
	}
}

func (r *Room) dispatch(playerID string, data []byte) {
	var env Envelope
	if err := json.Unmarshal(data, &env); err != nil {
		r.send(playerID, EvtError, ErrorPayload{Message: "bad envelope"})
		return
	}

	// ready is always handled by the room, not the game
	if env.Event == EvtReady {
		r.handleReady(playerID)
		return
	}

	if r.game == nil {
		r.send(playerID, EvtError, ErrorPayload{Message: "game not started"})
		return
	}

	var payload json.RawMessage = env.Payload
	r.game.Handle(PlayerAction{PlayerID: playerID, Event: env.Event, Payload: payload})
}

func (r *Room) handleReady(playerID string) {
	r.ready[playerID] = true
	log.Printf("[%s] player %s ready (%d/%d)\n", r.ID, playerID, len(r.ready), len(r.conns))

	// start as soon as at least 2 players are ready
	if r.game == nil && len(r.ready) >= 2 {
		players := make(map[string]*Player)
		for id := range r.ready {
			players[id] = NewPlayer(id, r.conns[id])
		}
		r.game = NewGame(r, players)
		go r.game.Run()
	}
}

// --- messaging helpers (called from room goroutine or game) ---

// send delivers a message to a single player.
func (r *Room) send(playerID string, event string, payload any) {
	c := r.conns[playerID]
	if c == nil {
		return
	}
	select {
	case c.Send <- marshal(event, payload):
	default:
		log.Printf("[%s] send buffer full for %s, dropping\n", r.ID, playerID)
	}
}

// broadcast delivers a message to all players, optionally excluding one.
func (r *Room) broadcast(excludeID string, event string, payload any) {
	data := marshal(event, payload)
	for id, c := range r.conns {
		if id == excludeID {
			continue
		}
		select {
		case c.Send <- data:
		default:
		}
	}
}

// broadcastAll delivers to every player.
func (r *Room) broadcastAll(event string, payload any) {
	r.broadcast("", event, payload)
}

// PlayerIDs returns the current list of connected player IDs (called from WS goroutine before game starts).
func (r *Room) PlayerIDs() []string {
	// this is only safe to call before the room goroutine starts (during Join in handleWS)
	ids := make([]string, 0, len(r.conns))
	for id := range r.conns {
		ids = append(ids, id)
	}
	return ids
}

// PlayerCount is safe to call from any goroutine only when called before Run() starts.
func (r *Room) PlayerCount() int {
	return len(r.conns)
}
