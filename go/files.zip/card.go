package main

// Element represents the elemental type of an attack or defense card.
type Element int

const (
	ElementNormal   Element = iota
	ElementDarkness Element = iota
	ElementWater    Element = iota
	ElementFire     Element = iota
	ElementRock     Element = iota
	ElementWood     Element = iota
	ElementLight    Element = iota
)

var elementNames = map[Element]string{
	ElementNormal:   "normal",
	ElementDarkness: "darkness",
	ElementWater:    "water",
	ElementFire:     "fire",
	ElementRock:     "rock",
	ElementWood:     "wood",
	ElementLight:    "light",
}

func (e Element) String() string {
	if name, ok := elementNames[e]; ok {
		return name
	}
	return "unknown"
}

// ValidDefenders maps each attack element to the set of defense elements that can counter it.
// An empty slice means no valid defense exists (Light).
var ValidDefenders = map[Element][]Element{
	ElementNormal:   {ElementNormal, ElementDarkness, ElementWater, ElementFire, ElementRock, ElementWood, ElementLight},
	ElementDarkness: {ElementNormal, ElementDarkness, ElementWater, ElementFire, ElementRock, ElementWood, ElementLight},
	ElementWater:    {ElementFire},
	ElementFire:     {ElementWater},
	ElementRock:     {ElementWood},
	ElementWood:     {ElementRock},
	ElementLight:    {},
}

// Rarity is the card rarity tier.
type Rarity int

const (
	Common    Rarity = iota
	Uncommon  Rarity = iota
	Rare      Rarity = iota
	Legendary Rarity = iota
)

// CardTag is a bitmask of card types (a card can be more than one).
type CardTag int

const (
	TagAttack    CardTag = 1 << iota
	TagDefense   CardTag = 1 << iota
	TagMiracle   CardTag = 1 << iota
	TagConsumable CardTag = 1 << iota
	TagPlus      CardTag = 1 << iota // stackable add-on for attacks
)

// EffectTrigger defines when an effect activates.
type EffectTrigger int

const (
	OnPlay     EffectTrigger = iota // immediately when card is played
	OnHit      EffectTrigger = iota // if the target took at least 1 damage
	OnBlock    EffectTrigger = iota // if the defender fully negated the attack
	OnDeath    EffectTrigger = iota // when the card holder dies
	TScheduled EffectTrigger = iota // added to timeline (RoundsDelay rounds from now)
	TPermanent EffectTrigger = iota // registered in the permanent effects list
)

// TargetScope defines who an effect targets.
type TargetScope string

const (
	ScopeSelf         TargetScope = "self"
	ScopeAttacker     TargetScope = "attacker"
	ScopeDefender     TargetScope = "defender"
	ScopeRandom       TargetScope = "random"
	ScopeAllOpponents TargetScope = "allOpponents"
	ScopeAll          TargetScope = "all"
)

// Effect is a side effect carried by a card.
type Effect struct {
	Trigger     EffectTrigger `json:"trigger"`
	RoundsDelay int           `json:"roundsDelay,omitempty"`
	Scope       TargetScope   `json:"scope"`
	Payload     string        `json:"payload"` // effect identifier resolved by the effect system
	Value       int           `json:"value,omitempty"`
}

// ProbabilityBranch is one possible outcome of a probabilistic card.
type ProbabilityBranch struct {
	Weight  int         `json:"weight"` // relative weight for RNG resolution
	Damage  int         `json:"damage"`
	Element Element     `json:"element"`
	Targets TargetScope `json:"targets"`
	Effects []Effect    `json:"effects,omitempty"`
}

// Card is a unified card type — attack, defense, miracle, consumable, or any combination.
type Card struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	Img  string `json:"img,omitempty"`

	Rarity Rarity  `json:"rarity"`
	Price  int     `json:"price"`
	Tags   CardTag `json:"tags"`

	// attack fields
	AttackDamage  int     `json:"attackDamage,omitempty"`
	AttackElement Element `json:"attackElement"`
	IsPlus        bool    `json:"isPlus,omitempty"` // can be layered on top of other attacks
	IsAoE         bool    `json:"isAoE,omitempty"`  // hits all opponents; cannot stack

	// defense fields
	DefenseValue   int     `json:"defenseValue,omitempty"`
	DefenseElement Element `json:"defenseElement,omitempty"` // element this card defends against
	IsReflect      bool    `json:"isReflect,omitempty"`      // sends attack back to attacker
	IsSwingBack    bool    `json:"isSwingBack,omitempty"`    // redirects to random player

	// probability
	IsProbabilistic bool                `json:"isProbabilistic,omitempty"`
	Branches        []ProbabilityBranch `json:"branches,omitempty"`

	Effects []Effect `json:"effects,omitempty"`
}

func (c *Card) HasTag(tag CardTag) bool  { return c.Tags&tag != 0 }
func (c *Card) IsAttack() bool           { return c.HasTag(TagAttack) }
func (c *Card) IsDefense() bool          { return c.HasTag(TagDefense) }
func (c *Card) IsMiracle() bool          { return c.HasTag(TagMiracle) }
func (c *Card) IsConsumable() bool       { return c.HasTag(TagConsumable) }

// CanDefend checks if a defense card's element is valid against the incoming attack element.
func CanDefend(attackElement, defenseElement Element) bool {
	for _, e := range ValidDefenders[attackElement] {
		if e == defenseElement {
			return true
		}
	}
	return false
}

// ResolveStack reduces an ordered list of attack cards to a single element and total damage.
// Reduction rules (applied left to right):
//
//	light + (any except darkness) = that element
//	light + darkness              = normal
//	element + normal              = normal
func ResolveStack(stack []Card) (element Element, damage int) {
	if len(stack) == 0 {
		return ElementNormal, 0
	}
	element = stack[0].AttackElement
	damage = stack[0].AttackDamage
	for _, c := range stack[1:] {
		element = neutralize(element, c.AttackElement)
		damage += c.AttackDamage
	}
	return
}

func neutralize(a, b Element) Element {
	switch {
	case a == ElementLight && b == ElementDarkness:
		return ElementNormal
	case b == ElementLight && a == ElementDarkness:
		return ElementNormal
	case a == ElementLight:
		return b
	case b == ElementLight:
		return a
	case a == ElementNormal || b == ElementNormal:
		return ElementNormal
	default:
		return a
	}
}
