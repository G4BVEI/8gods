package main

import "encoding/json"

// ---- inbound (client → server) ----
const (
	EvtReady           = "ready"
	EvtPlayCard        = "playCard"        // play main attack / miracle / consumable
	EvtAddToStack      = "addToStack"      // add a + card on top of current attack
	EvtFinalizeAttack  = "finalizeAttack"  // done stacking, send attack to target
	EvtFinalizeDefense = "finalizeDefense" // send defense response (cards or reflect/swingback)
)

// ---- outbound (server → client) ----
const (
	EvtJoined        = "joined"
	EvtPlayerJoined  = "playerJoined"
	EvtPlayerLeft    = "playerLeft"
	EvtGameStart     = "gameStart"
	EvtTurnStart     = "turnStart"
	EvtCardPlayed    = "cardPlayed"
	EvtStackUpdated  = "stackUpdated"
	EvtDefensePhase  = "defensePhase"
	EvtDefenseResult = "defenseResult"
	EvtPlayerUpdate  = "playerUpdate"
	EvtRoundEnd      = "roundEnd"
	EvtPlayerDied    = "playerDied"
	EvtGameOver      = "gameOver"
	EvtError         = "error"
)

// Envelope is the wire format for all messages.
type Envelope struct {
	Event   string          `json:"event"`
	Payload json.RawMessage `json:"payload,omitempty"`
}

func marshal(event string, payload any) []byte {
	raw, _ := json.Marshal(payload)
	env := Envelope{Event: event, Payload: json.RawMessage(raw)}
	data, _ := json.Marshal(env)
	return data
}

// ---- inbound payloads ----

type PlayCardPayload struct {
	CardID   string `json:"cardId"`
	TargetID string `json:"targetId,omitempty"` // empty = auto (only other alive player)
}

type AddToStackPayload struct {
	CardID string `json:"cardId"`
}

// FinalizeDefensePayload carries the defender's response.
// Exactly one of DefenseCardIDs, Reflect, or SwingBack should be set.
type FinalizeDefensePayload struct {
	DefenseCardIDs []string `json:"defenseCardIds,omitempty"` // stack of defense cards
	ReflectCardID  string   `json:"reflectCardId,omitempty"`  // play a reflect card
	SwingCardID    string   `json:"swingCardId,omitempty"`    // play a swingback card
}

// ---- outbound payloads ----

type JoinedPayload struct {
	PlayerID string   `json:"playerId"`
	RoomID   string   `json:"roomId"`
	Players  []string `json:"players"`
}

type PlayerJoinedPayload struct {
	PlayerID string `json:"playerId"`
}

type PlayerLeftPayload struct {
	PlayerID string `json:"playerId"`
}

type PlayerSnapshot struct {
	ID    string `json:"id"`
	HP    int    `json:"hp"`
	Mana  int    `json:"mana"`
	Money int    `json:"money"`
}

type GameStartPayload struct {
	Players     []PlayerSnapshot `json:"players"`
	TurnOrder   []string         `json:"turnOrder"`
	YourAttack  []Card           `json:"yourAttack"`
	YourSecond  []Card           `json:"yourSecond"`
}

type TurnStartPayload struct {
	ActivePlayerID string `json:"activePlayerId"`
	Round          int    `json:"round"`
	IsYourTurn     bool   `json:"isYourTurn"`
}

type CardPlayedPayload struct {
	PlayerID string `json:"playerId"`
	Card     Card   `json:"card"`
}

type StackUpdatedPayload struct {
	AttackerID      string `json:"attackerId"`
	Stack           []Card `json:"stack"`
	ResolvedElement string `json:"resolvedElement"`
	TotalDamage     int    `json:"totalDamage"`
}

type DefensePhasePayload struct {
	AttackerID      string `json:"attackerId"`
	TargetID        string `json:"targetId"`
	Stack           []Card `json:"stack"`
	ResolvedElement string `json:"resolvedElement"`
	TotalDamage     int    `json:"totalDamage"`
}

type DefenseResultPayload struct {
	AttackerID    string `json:"attackerId"`
	TargetID      string `json:"targetId"`
	DamageDealt   int    `json:"damageDealt"`
	DamageBlocked int    `json:"damageBlocked"`
	Reflected     bool   `json:"reflected,omitempty"`
	SwungBack     bool   `json:"swungBack,omitempty"`
	NewTargetID   string `json:"newTargetId,omitempty"`
}

type PlayerUpdatePayload struct {
	PlayerID string `json:"playerId"`
	HP       int    `json:"hp"`
	Mana     int    `json:"mana"`
	Money    int    `json:"money"`
	NewCards []Card `json:"newCards,omitempty"` // cards drawn after being hit
}

type RoundEndPayload struct {
	Round int `json:"round"`
}

type PlayerDiedPayload struct {
	PlayerID string `json:"playerId"`
}

type GameOverPayload struct {
	WinnerID string `json:"winnerId"`
}

type ErrorPayload struct {
	Message string `json:"message"`
}
