package main

// ActiveEffect tracks a status effect currently applied to a player.
type ActiveEffect struct {
	Payload string `json:"payload"`
	Value   int    `json:"value,omitempty"`
}

// Player holds all runtime state for one player in a game.
type Player struct {
	ID    string
	Conn  *Connection // nil if disconnected

	HP    int
	Mana  int
	Money int

	AttackHand    []Card
	SecondaryHand []Card

	Effects []ActiveEffect

	IsAlive bool
}

func NewPlayer(id string, conn *Connection) *Player {
	return &Player{
		ID:      id,
		Conn:    conn,
		HP:      40,
		Mana:    10,
		Money:   15,
		IsAlive: true,
	}
}

func (p *Player) Snapshot() PlayerSnapshot {
	return PlayerSnapshot{ID: p.ID, HP: p.HP, Mana: p.Mana, Money: p.Money}
}

// TakeDamage applies damage and returns the actual amount dealt.
// Darkness instakills if not fully blocked.
func (p *Player) TakeDamage(amount int, element Element) int {
	if element == ElementDarkness && amount > 0 {
		p.HP = 0
		return p.HP
	}
	p.HP -= amount
	if p.HP < 0 {
		p.HP = 0
	}
	return amount
}

func (p *Player) Heal(amount int) {
	p.HP += amount
}

func (p *Player) HasDebuff(payload string) bool {
	for _, e := range p.Effects {
		if e.Payload == payload {
			return true
		}
	}
	return false
}

func (p *Player) ApplyEffect(e ActiveEffect) {
	p.Effects = append(p.Effects, e)
}

func (p *Player) ClearNegativeEffects() {
	p.Effects = []ActiveEffect{}
}

// --- hand helpers ---

func (p *Player) FindInAttackHand(id string) (card Card, idx int, ok bool) {
	for i, c := range p.AttackHand {
		if c.ID == id {
			return c, i, true
		}
	}
	return Card{}, -1, false
}

func (p *Player) FindInSecondaryHand(id string) (card Card, idx int, ok bool) {
	for i, c := range p.SecondaryHand {
		if c.ID == id {
			return c, i, true
		}
	}
	return Card{}, -1, false
}

// FindCard searches both hands and returns the card, its source hand, and index.
func (p *Player) FindCard(id string) (card Card, hand string, idx int, ok bool) {
	if c, i, found := p.FindInAttackHand(id); found {
		return c, "attack", i, true
	}
	if c, i, found := p.FindInSecondaryHand(id); found {
		return c, "secondary", i, true
	}
	return Card{}, "", -1, false
}

func (p *Player) RemoveFromAttackHand(idx int) {
	p.AttackHand = append(p.AttackHand[:idx], p.AttackHand[idx+1:]...)
}

func (p *Player) RemoveFromSecondaryHand(idx int) {
	p.SecondaryHand = append(p.SecondaryHand[:idx], p.SecondaryHand[idx+1:]...)
}

func (p *Player) RemoveCard(hand string, idx int) {
	switch hand {
	case "attack":
		p.RemoveFromAttackHand(idx)
	case "secondary":
		p.RemoveFromSecondaryHand(idx)
	}
}
