package main

// ScheduledEntry is an effect queued to fire at a specific round.
type ScheduledEntry struct {
	PlayerID string
	Effect   Effect
}

// PermanentEffect is an always-active game-wide or player-scoped effect.
type PermanentEffect struct {
	Payload  string
	Value    int
	PlayerID string // empty = game-wide
}

// Timeline tracks scheduled per-round effects and permanent effects.
//
// Design (per time3.txt):
//   - timeline[round] holds entries that get applied at the start of that round
//   - permanent effects live in their own slice and are never automatically cleared
//   - the timeline only registers when effects get applied to the effect list, not how,
//     as each effect has its own trigger/priority handled by the effect system
type Timeline struct {
	entries   map[int][]ScheduledEntry
	Permanent []PermanentEffect
}

func NewTimeline() *Timeline {
	return &Timeline{entries: make(map[int][]ScheduledEntry)}
}

// Schedule queues an effect for a specific future round.
func (t *Timeline) Schedule(round int, playerID string, e Effect) {
	t.entries[round] = append(t.entries[round], ScheduledEntry{PlayerID: playerID, Effect: e})
}

// AddPermanent registers a permanent effect.
func (t *Timeline) AddPermanent(payload string, value int, playerID string) {
	t.Permanent = append(t.Permanent, PermanentEffect{Payload: payload, Value: value, PlayerID: playerID})
}

// Flush returns and removes all entries scheduled for the given round.
func (t *Timeline) Flush(round int) []ScheduledEntry {
	entries := t.entries[round]
	delete(t.entries, round)
	return entries
}

// HasPermanent checks if a permanent effect with the given payload is active.
func (t *Timeline) HasPermanent(payload string) bool {
	for _, p := range t.Permanent {
		if p.Payload == payload {
			return true
		}
	}
	return false
}
