package main

import (
	"encoding/json"
	"log"
	"math/rand"
)

// GamePhase is the current phase of the game state machine.
type GamePhase int

const (
	PhaseAttack     GamePhase = iota // active player must play attack / miracle / consumable
	PhaseStacking   GamePhase = iota // active player may add + cards or finalize
	PhaseDefense    GamePhase = iota // target player must respond
	PhaseGameOver   GamePhase = iota
)

// AttackContext holds the in-flight attack during stacking and defense phases.
type AttackContext struct {
	AttackerID      string
	TargetID        string
	Stack           []Card
	ResolvedElement Element
	TotalDamage     int
}

// PlayerAction is an inbound message from a player, forwarded from the room.
type PlayerAction struct {
	PlayerID string
	Event    string
	Payload  json.RawMessage
}

// Game runs the game loop and owns all game state.
// It is driven by Handle() which is called synchronously from the room goroutine.
type Game struct {
	room    *Room
	players map[string]*Player
	order   []string // turn order (player IDs)
	curIdx  int      // index into order
	round   int

	phase         GamePhase
	attackCtx     *AttackContext
	timeline      *Timeline
	attackDecks   map[string][]Card
	secondDecks   map[string][]Card

	actions chan PlayerAction
}

func NewGame(room *Room, players map[string]*Player) *Game {
	order := make([]string, 0, len(players))
	for id := range players {
		order = append(order, id)
	}
	rand.Shuffle(len(order), func(i, j int) { order[i], order[j] = order[j], order[i] })

	atkDecks := map[string][]Card{}
	secDecks := map[string][]Card{}

	for id, p := range players {
		atk := testAttackDeck()
		sec := testSecondaryDeck()
		p.AttackHand, atk = drawN(atk, 4)
		p.SecondaryHand, sec = drawN(sec, 4)
		atkDecks[id] = atk
		secDecks[id] = sec
	}

	return &Game{
		room:        room,
		players:     players,
		order:       order,
		curIdx:      0,
		round:       1,
		phase:       PhaseAttack,
		timeline:    NewTimeline(),
		attackDecks: atkDecks,
		secondDecks: secDecks,
		actions:     make(chan PlayerAction, 32),
	}
}

// Run broadcasts game start and begins the turn loop.
// Runs in its own goroutine.
func (g *Game) Run() {
	// send each player their personal game start payload
	for id, p := range g.players {
		snapshots := make([]PlayerSnapshot, 0, len(g.players))
		for _, op := range g.players {
			snapshots = append(snapshots, op.Snapshot())
		}
		g.room.send(id, EvtGameStart, GameStartPayload{
			Players:    snapshots,
			TurnOrder:  g.order,
			YourAttack: p.AttackHand,
			YourSecond: p.SecondaryHand,
		})
	}

	g.broadcastTurnStart()

	// drain the action channel — Handle() pushes here
	for action := range g.actions {
		g.process(action)
		if g.phase == PhaseGameOver {
			return
		}
	}
}

// Handle is called by the room goroutine to forward player actions into the game.
func (g *Game) Handle(action PlayerAction) {
	g.actions <- action
}

// process dispatches an action based on the current phase.
func (g *Game) process(action PlayerAction) {
	log.Printf("[game] phase=%d event=%s from=%s\n", g.phase, action.Event, action.PlayerID)

	switch g.phase {
	case PhaseAttack:
		if action.PlayerID != g.currentPlayerID() {
			g.sendError(action.PlayerID, "not your turn")
			return
		}
		if action.Event == EvtPlayCard {
			g.handlePlayCard(action)
		}

	case PhaseStacking:
		if action.PlayerID != g.currentPlayerID() {
			g.sendError(action.PlayerID, "not your turn to stack")
			return
		}
		switch action.Event {
		case EvtAddToStack:
			g.handleAddToStack(action)
		case EvtFinalizeAttack:
			g.handleFinalizeAttack()
		}

	case PhaseDefense:
		if g.attackCtx == nil || action.PlayerID != g.attackCtx.TargetID {
			g.sendError(action.PlayerID, "not your defense turn")
			return
		}
		if action.Event == EvtFinalizeDefense {
			g.handleFinalizeDefense(action)
		}
	}
}

// --- phase handlers ---

func (g *Game) handlePlayCard(action PlayerAction) {
	var p PlayCardPayload
	json.Unmarshal(action.Payload, &p)

	player := g.players[action.PlayerID]
	card, hand, idx, ok := player.FindCard(p.CardID)
	if !ok {
		g.sendError(action.PlayerID, "card not in hand: "+p.CardID)
		return
	}

	// miracle / consumable: resolve immediately, end turn
	if card.IsMiracle() || card.IsConsumable() {
		player.RemoveCard(hand, idx)
		g.resolveEffect(player, card.Effects)
		g.room.broadcastAll(EvtCardPlayed, CardPlayedPayload{PlayerID: action.PlayerID, Card: card})
		g.room.broadcastAll(EvtPlayerUpdate, player.Snapshot())
		g.endTurn()
		return
	}

	// must be a main (non-+) attack
	if !card.IsAttack() {
		g.sendError(action.PlayerID, "must play attack, miracle, or consumable")
		return
	}
	if card.IsPlus {
		g.sendError(action.PlayerID, "must lead with a non-+ attack card")
		return
	}

	// resolve target
	targetID := p.TargetID
	if targetID == "" {
		targetID = g.pickTarget(action.PlayerID)
	}
	if targetID == "" {
		g.sendError(action.PlayerID, "no valid target")
		return
	}

	player.RemoveCard(hand, idx)

	g.attackCtx = &AttackContext{
		AttackerID: action.PlayerID,
		TargetID:   targetID,
		Stack:      []Card{card},
	}
	g.attackCtx.ResolvedElement, g.attackCtx.TotalDamage = ResolveStack(g.attackCtx.Stack)

	g.room.broadcastAll(EvtCardPlayed, CardPlayedPayload{PlayerID: action.PlayerID, Card: card})
	g.phase = PhaseStacking

	// notify attacker they can now add + cards or finalize
	g.room.broadcastAll(EvtStackUpdated, g.stackPayload())
}

func (g *Game) handleAddToStack(action PlayerAction) {
	var p AddToStackPayload
	json.Unmarshal(action.Payload, &p)

	player := g.players[action.PlayerID]
	card, hand, idx, ok := player.FindCard(p.CardID)
	if !ok {
		g.sendError(action.PlayerID, "card not in hand: "+p.CardID)
		return
	}
	if !card.IsPlus {
		g.sendError(action.PlayerID, "only + cards can be stacked")
		return
	}

	player.RemoveCard(hand, idx)
	g.attackCtx.Stack = append(g.attackCtx.Stack, card)
	g.attackCtx.ResolvedElement, g.attackCtx.TotalDamage = ResolveStack(g.attackCtx.Stack)

	g.room.broadcastAll(EvtStackUpdated, g.stackPayload())
}

func (g *Game) handleFinalizeAttack() {
	ctx := g.attackCtx
	g.phase = PhaseDefense

	// notify everyone of the defense phase, with full stack info
	g.room.broadcastAll(EvtDefensePhase, DefensePhasePayload{
		AttackerID:      ctx.AttackerID,
		TargetID:        ctx.TargetID,
		Stack:           ctx.Stack,
		ResolvedElement: ctx.ResolvedElement.String(),
		TotalDamage:     ctx.TotalDamage,
	})
}

func (g *Game) handleFinalizeDefense(action PlayerAction) {
	var p FinalizeDefensePayload
	json.Unmarshal(action.Payload, &p)

	ctx := g.attackCtx
	defender := g.players[ctx.TargetID]
	attacker := g.players[ctx.AttackerID]
	result := DefenseResultPayload{AttackerID: ctx.AttackerID, TargetID: ctx.TargetID}

	// --- reflect ---
	if p.ReflectCardID != "" {
		card, hand, idx, ok := defender.FindCard(p.ReflectCardID)
		if !ok || !card.IsReflect {
			g.sendError(action.PlayerID, "invalid reflect card")
			return
		}
		defender.RemoveCard(hand, idx)
		result.Reflected = true
		dmg := attacker.TakeDamage(ctx.TotalDamage, ctx.ResolvedElement)
		result.DamageDealt = dmg
		g.room.broadcastAll(EvtDefenseResult, result)
		g.room.broadcastAll(EvtPlayerUpdate, attacker.Snapshot())
		g.checkDeath(attacker)
		g.endTurn()
		return
	}

	// --- swingback ---
	if p.SwingCardID != "" {
		card, hand, idx, ok := defender.FindCard(p.SwingCardID)
		if !ok || !card.IsSwingBack {
			g.sendError(action.PlayerID, "invalid swingback card")
			return
		}
		defender.RemoveCard(hand, idx)
		newTargetID := g.pickTarget(ctx.TargetID) // random other alive player
		if newTargetID == "" {
			newTargetID = ctx.AttackerID
		}
		newTarget := g.players[newTargetID]
		result.SwungBack = true
		result.NewTargetID = newTargetID
		dmg := newTarget.TakeDamage(ctx.TotalDamage, ctx.ResolvedElement)
		result.DamageDealt = dmg
		g.room.broadcastAll(EvtDefenseResult, result)
		g.room.broadcastAll(EvtPlayerUpdate, newTarget.Snapshot())
		g.checkDeath(newTarget)
		g.endTurn()
		return
	}

	// --- standard defense (stack of defense cards) ---
	blocked := 0
	for _, cardID := range p.DefenseCardIDs {
		card, hand, idx, ok := defender.FindCard(cardID)
		if !ok || !card.IsDefense() {
			continue
		}
		// validate element match
		if !CanDefend(ctx.ResolvedElement, card.DefenseElement) {
			g.sendError(action.PlayerID, "card "+card.Name+" can't defend "+ctx.ResolvedElement.String())
			continue
		}
		defender.RemoveCard(hand, idx)
		blocked += card.DefenseValue

		// apply any on-play effects from defense card
		g.resolveEffect(defender, card.Effects)
	}
	if blocked > ctx.TotalDamage {
		blocked = ctx.TotalDamage
	}

	finalDamage := ctx.TotalDamage - blocked
	result.DamageBlocked = blocked
	result.DamageDealt = finalDamage

	if finalDamage > 0 {
		defender.TakeDamage(finalDamage, ctx.ResolvedElement)
		// defender draws a card after being hit by a non-AoE attack
		if newCard := g.drawSecondaryCard(ctx.TargetID); newCard != nil {
			defender.SecondaryHand = append(defender.SecondaryHand, *newCard)
			g.room.send(ctx.TargetID, EvtPlayerUpdate, PlayerUpdatePayload{
				PlayerID: ctx.TargetID,
				HP:       defender.HP,
				Mana:     defender.Mana,
				Money:    defender.Money,
				NewCards: []Card{*newCard},
			})
		}
	}

	g.room.broadcastAll(EvtDefenseResult, result)
	g.room.broadcastAll(EvtPlayerUpdate, defender.Snapshot())
	g.checkDeath(defender)
	g.endTurn()
}

// --- helpers ---

func (g *Game) stackPayload() StackUpdatedPayload {
	ctx := g.attackCtx
	return StackUpdatedPayload{
		AttackerID:      ctx.AttackerID,
		Stack:           ctx.Stack,
		ResolvedElement: ctx.ResolvedElement.String(),
		TotalDamage:     ctx.TotalDamage,
	}
}

func (g *Game) resolveEffect(target *Player, effects []Effect) {
	for _, e := range effects {
		switch e.Payload {
		case "heal":
			target.Heal(e.Value)
		case "cleanseNegative":
			target.ClearNegativeEffects()
		}
	}
}

func (g *Game) pickTarget(excludeID string) string {
	alive := []string{}
	for _, id := range g.order {
		if id != excludeID && g.players[id].IsAlive {
			alive = append(alive, id)
		}
	}
	if len(alive) == 0 {
		return ""
	}
	return alive[rand.Intn(len(alive))]
}

func (g *Game) currentPlayerID() string {
	return g.order[g.curIdx]
}

func (g *Game) checkDeath(p *Player) {
	if p.HP <= 0 && p.IsAlive {
		p.IsAlive = false
		g.room.broadcastAll(EvtPlayerDied, PlayerDiedPayload{PlayerID: p.ID})
		log.Printf("[game] player %s died\n", p.ID)

		if g.aliveCount() == 1 {
			winner := g.lastAlive()
			g.room.broadcastAll(EvtGameOver, GameOverPayload{WinnerID: winner.ID})
			g.phase = PhaseGameOver
		}
	}
}

func (g *Game) aliveCount() int {
	n := 0
	for _, p := range g.players {
		if p.IsAlive {
			n++
		}
	}
	return n
}

func (g *Game) lastAlive() *Player {
	for _, p := range g.players {
		if p.IsAlive {
			return p
		}
	}
	return nil
}

func (g *Game) endTurn() {
	if g.phase == PhaseGameOver {
		return
	}
	g.attackCtx = nil

	// draw one attack card for the player who just attacked
	attackerID := g.order[g.curIdx]
	attacker := g.players[attackerID]
	if card := g.drawAttackCard(attackerID); card != nil {
		attacker.AttackHand = append(attacker.AttackHand, *card)
		g.room.send(attackerID, EvtPlayerUpdate, PlayerUpdatePayload{
			PlayerID: attackerID,
			HP:       attacker.HP,
			Mana:     attacker.Mana,
			Money:    attacker.Money,
			NewCards: []Card{*card},
		})
	}

	// advance to next alive player
	prev := g.curIdx
	for {
		g.curIdx = (g.curIdx + 1) % len(g.order)
		if g.curIdx < prev || (g.curIdx == 0 && prev != 0) {
			// wrapped around — new round
			g.onRoundEnd()
		}
		if g.players[g.order[g.curIdx]].IsAlive {
			break
		}
	}

	g.phase = PhaseAttack
	g.broadcastTurnStart()
}

func (g *Game) onRoundEnd() {
	g.round++
	entries := g.timeline.Flush(g.round)
	for _, entry := range entries {
		if p, ok := g.players[entry.PlayerID]; ok {
			g.resolveEffect(p, []Effect{entry.Effect})
		}
	}
	g.room.broadcastAll(EvtRoundEnd, RoundEndPayload{Round: g.round})
	log.Printf("[game] round %d started\n", g.round)
}

func (g *Game) broadcastTurnStart() {
	activeID := g.currentPlayerID()
	for id := range g.players {
		g.room.send(id, EvtTurnStart, TurnStartPayload{
			ActivePlayerID: activeID,
			Round:          g.round,
			IsYourTurn:     id == activeID,
		})
	}
}

func (g *Game) drawAttackCard(playerID string) *Card {
	deck := g.attackDecks[playerID]
	if len(deck) == 0 {
		return nil
	}
	card := deck[0]
	g.attackDecks[playerID] = deck[1:]
	return &card
}

func (g *Game) drawSecondaryCard(playerID string) *Card {
	deck := g.secondDecks[playerID]
	if len(deck) == 0 {
		return nil
	}
	card := deck[0]
	g.secondDecks[playerID] = deck[1:]
	return &card
}

func (g *Game) sendError(playerID, msg string) {
	g.room.send(playerID, EvtError, ErrorPayload{Message: msg})
}
